import React, { Component } from 'react';
import axios from 'axios';
import _ from 'lodash';

export default class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      text:'',
      data:[],
      filterData: []
    }
    this.handleClick = this.handleClick.bind(this);
    this.renderTable = this.renderTable.bind(this);
  }

  componentWillMount() {
     axios.get('http://jsonplaceholder.typicode.com/posts')
      .then((response) => {
            this.setState({
              data: response.data,
              filterData: response.data,
            });
      })
      .catch((error) => {
      }); 
  }
  renderTable = (data) => {
         return _.map(data, (value) => {
            return (
              <tr> 
                <td>{value.id}</td>
                <td>{value.userId}</td>
                <td>{value.title}</td>
                <td>{value.body}</td>
              </tr>
            )
        });
      
  }
  handleClick(e){
  
    let data = _.filter(this.state.data, (value) => {
         if(_.includes(value.title,e.target.value)) {
          return true;
        }
        else {
           return false;
        }
    });
    console.log(data, data.length)
    this.setState({
      filterData: data
    })
  }
  render() {
    return (
      <div className='main_home'>
        <div className='main_heading'>
            <h3 class='main_heading_label'>List of Post</h3>
        </div>

         <div className='main_search'>
            <label> Filer Data As Per Title  :</label>
            <input class='main_input' type='text' onChange={this.handleClick} />
        </div>

        <div className='main_table'>
            <table>
              <thead>
                <tr>
                    <th>No</th>
                    <th>User Id </th>
                    <th>Title</th>
                    <th>Description</th>
                </tr>
              </thead>

              <tbody>

                {this.state.data <= 1 ? (
                  <tr>
                      <td> No Data Found </td>
                  </tr>
                ) : (
                    this.renderTable(this.state.filterData)
                )}
                  
              </tbody>

            </table>
        </div>

      </div>
    );
  }
}
